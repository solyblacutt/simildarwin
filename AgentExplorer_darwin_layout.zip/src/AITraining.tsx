import { useState } from 'react';
import './AITraining.css';

interface Source {
  filename: string;
  chunkIndex: number;
  totalChunks: number;
  text: string;
  score: number;
}

interface Stats {
  totalChunks: number;
  totalFiles: number;
  files: string[];
}

const API_BASE = 'http://localhost:3000/api';

export function AITraining() {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState('');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [sources, setSources] = useState<Source[]>([]);
  const [querying, setQuerying] = useState(false);
  const [stats, setStats] = useState<Stats | null>(null);
  const [activeView, setActiveView] = useState<'upload' | 'query' | 'comparison'>('upload');

  const loadStats = async () => {
    try {
      const response = await fetch(`${API_BASE}/stats`);
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setUploadStatus('');
    }
  };

  const handleUpload = async () => {
    if (!file) {
      setUploadStatus('Please select a file first');
      return;
    }

    setUploading(true);
    setUploadStatus('Uploading and processing...');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch(`${API_BASE}/upload`, {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();
      
      if (data.success) {
        setUploadStatus(`✓ ${data.message}`);
        setFile(null);
        loadStats();
      } else {
        setUploadStatus(`✗ Error: ${data.error}`);
      }
    } catch (error: any) {
      setUploadStatus(`✗ Upload failed: ${error.message}`);
    } finally {
      setUploading(false);
    }
  };

  const handleQuery = async () => {
    if (!question.trim()) {
      return;
    }

    setQuerying(true);
    setAnswer('');
    setSources([]);

    try {
      const response = await fetch(`${API_BASE}/query`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ question }),
      });

      const data = await response.json();
      
      if (data.answer) {
        setAnswer(data.answer);
        setSources(data.sources || []);
      } else {
        setAnswer(`Error: ${data.error}`);
      }
    } catch (error: any) {
      setAnswer(`Query failed: ${error.message}`);
    } finally {
      setQuerying(false);
    }
  };

  const handleClear = async () => {
    if (!confirm('Are you sure you want to clear all uploaded lecture notes?')) {
      return;
    }

    try {
      await fetch(`${API_BASE}/clear`, { method: 'DELETE' });
      setStats(null);
      setAnswer('');
      setSources([]);
      setUploadStatus('Knowledge base cleared');
    } catch (error) {
      setUploadStatus('Failed to clear knowledge base');
    }
  };

  return (
    <div className="ai-training-section">
      <div className="training-header">
        <h2>🧠 AI Training with Lecture Notes</h2>
        <p className="training-subtitle">
          Demonstrate RAG (Retrieval-Augmented Generation) - Upload lecture notes and query the AI knowledge base
        </p>
      </div>

      <div className="training-nav">
        <button 
          className={activeView === 'upload' ? 'active' : ''} 
          onClick={() => setActiveView('upload')}
        >
          📤 Upload Lectures
        </button>
        <button 
          className={activeView === 'query' ? 'active' : ''} 
          onClick={() => { setActiveView('query'); loadStats(); }}
        >
          💬 Ask Questions
        </button>
        <button 
          className={activeView === 'comparison' ? 'active' : ''} 
          onClick={() => setActiveView('comparison')}
        >
          🔄 RAG vs Fine-Tuning
        </button>
      </div>

      {activeView === 'upload' && (
        <div className="training-content">
          <div className="upload-panel">
            <h3>Upload Lecture Notes</h3>
            <p className="hint">Supported formats: PDF, TXT</p>
            
            <div className="upload-area">
              <input
                type="file"
                accept=".pdf,.txt"
                onChange={handleFileChange}
                disabled={uploading}
              />
              
              {file && (
                <div className="file-info">
                  <span className="file-name">📄 {file.name}</span>
                  <span className="file-size">({(file.size / 1024).toFixed(1)} KB)</span>
                </div>
              )}

              <button 
                className="upload-btn" 
                onClick={handleUpload} 
                disabled={!file || uploading}
              >
                {uploading ? 'Processing...' : 'Upload & Process'}
              </button>

              {uploadStatus && (
                <div className={`status-message ${uploadStatus.startsWith('✓') ? 'success' : uploadStatus.startsWith('✗') ? 'error' : 'info'}`}>
                  {uploadStatus}
                </div>
              )}
            </div>

            {stats && stats.totalFiles > 0 && (
              <div className="stats-box">
                <h4>Knowledge Base Stats</h4>
                <div className="stat-item">
                  <span className="stat-label">Total Files:</span>
                  <span className="stat-value">{stats.totalFiles}</span>
                </div>
                <div className="stat-item">
                  <span className="stat-label">Total Chunks:</span>
                  <span className="stat-value">{stats.totalChunks}</span>
                </div>
                <div className="stat-item">
                  <span className="stat-label">Files:</span>
                  <ul className="file-list">
                    {stats.files.map((filename, idx) => (
                      <li key={idx}>{filename}</li>
                    ))}
                  </ul>
                </div>
                <button className="clear-btn" onClick={handleClear}>
                  Clear Knowledge Base
                </button>
              </div>
            )}
          </div>

          <div className="info-panel">
            <h3>How RAG Works</h3>
            <div className="step">
              <span className="step-number">1</span>
              <div className="step-content">
                <h4>Chunk the Text</h4>
                <p>Lecture notes are split into manageable pieces (chunks) for better processing</p>
              </div>
            </div>
            <div className="step">
              <span className="step-number">2</span>
              <div className="step-content">
                <h4>Generate Embeddings</h4>
                <p>Each chunk is converted into a vector (numerical representation) using OpenAI's embedding model</p>
              </div>
            </div>
            <div className="step">
              <span className="step-number">3</span>
              <div className="step-content">
                <h4>Store in Vector Database</h4>
                <p>Vectors are stored locally in Vectra, allowing fast similarity searches</p>
              </div>
            </div>
            <div className="step">
              <span className="step-number">4</span>
              <div className="step-content">
                <h4>Query & Retrieve</h4>
                <p>When you ask a question, the system finds the most relevant chunks and uses them to generate an answer</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeView === 'query' && (
        <div className="training-content">
          <div className="query-panel">
            <h3>Ask Questions About Your Lecture Notes</h3>
            
            {!stats || stats.totalFiles === 0 ? (
              <div className="no-data-message">
                <p>📚 No lecture notes uploaded yet. Please upload some files first!</p>
                <button onClick={() => setActiveView('upload')}>Go to Upload</button>
              </div>
            ) : (
              <>
                <div className="query-input-area">
                  <textarea
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    placeholder="e.g., What are the key principles of symbiotic AI? How does RAG differ from fine-tuning?"
                    rows={3}
                    disabled={querying}
                  />
                  <button 
                    className="query-btn" 
                    onClick={handleQuery} 
                    disabled={querying || !question.trim()}
                  >
                    {querying ? 'Searching...' : 'Ask Question'}
                  </button>
                </div>

                {answer && (
                  <div className="answer-section">
                    <h4>🤖 AI Answer (RAG-powered)</h4>
                    <div className="answer-box">
                      {answer}
                    </div>

                    {sources.length > 0 && (
                      <div className="sources-section">
                        <h4>📖 Sources (Retrieved Context)</h4>
                        {sources.map((source, idx) => (
                          <div key={idx} className="source-card">
                            <div className="source-header">
                              <span className="source-filename">
                                {source.filename}
                              </span>
                              <span className="source-location">
                                Chunk {source.chunkIndex + 1}/{source.totalChunks}
                              </span>
                              <span className="source-score">
                                Relevance: {(source.score * 100).toFixed(1)}%
                              </span>
                            </div>
                            <div className="source-text">
                              {source.text}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {activeView === 'comparison' && (
        <div className="training-content">
          <div className="comparison-grid">
            <div className="comparison-card rag-card">
              <h3>🔍 RAG Approach</h3>
              <p className="card-label">What we're using now</p>
              
              <div className="pros-cons">
                <div className="pros">
                  <h4>✅ Advantages</h4>
                  <ul>
                    <li>Easy to update - just add new files</li>
                    <li>Source attribution - shows where answers come from</li>
                    <li>Cost-effective - no model retraining needed</li>
                    <li>Fast deployment - ready in hours/days</li>
                    <li>Works with latest information</li>
                  </ul>
                </div>
                <div className="cons">
                  <h4>⚠️ Limitations</h4>
                  <ul>
                    <li>Retrieval quality depends on chunking</li>
                    <li>Slight latency from database lookups</li>
                    <li>May miss complex contextual connections</li>
                  </ul>
                </div>
              </div>

              <div className="use-case">
                <strong>Best for:</strong> Educational platforms, frequently updated content, need for source citations
              </div>
            </div>

            <div className="comparison-card finetuning-card">
              <h3>🎯 Fine-Tuning Approach</h3>
              <p className="card-label">Alternative method</p>
              
              <div className="pros-cons">
                <div className="pros">
                  <h4>✅ Advantages</h4>
                  <ul>
                    <li>Deep domain understanding</li>
                    <li>Can replicate specific teaching style</li>
                    <li>Faster inference (no database lookup)</li>
                    <li>Works offline</li>
                    <li>Better at understanding jargon</li>
                  </ul>
                </div>
                <div className="cons">
                  <h4>⚠️ Limitations</h4>
                  <ul>
                    <li>Expensive ($1k-$50k for training)</li>
                    <li>Must retrain for new content</li>
                    <li>Requires ML expertise</li>
                    <li>No source attribution</li>
                    <li>Weeks/months to deploy</li>
                  </ul>
                </div>
              </div>

              <div className="use-case">
                <strong>Best for:</strong> Specialized domains, stable content, specific teaching style requirements
              </div>
            </div>
          </div>

          <div className="symbiotic-insight">
            <h3>🤝 Symbiotic AI Perspective</h3>
            <p>
              <strong>RAG embodies the "vivre ensemble" philosophy:</strong> The AI doesn't pretend to "know" everything 
              (which fine-tuning might imply). Instead, it transparently retrieves and cites sources, allowing humans 
              to verify, validate, and make informed decisions. This is AI as a collaborative tool, not an autonomous authority.
            </p>
            <p>
              <strong>Why this matters:</strong> In critical domains like education, medicine, and spaceflight, 
              transparency and traceability are essential. RAG shows its work, making it easier for humans to 
              maintain final authority and trust the AI's assistance.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
