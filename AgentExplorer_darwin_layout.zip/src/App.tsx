
import { useState } from 'react';
import './index.css';
import './Landing.css';
import Dashboard from './Dashboard';

export default function App(){
  const [showDemo, setShowDemo] = useState(false);

  return (
    <div>
      <nav className="navbar">
        <div className="inner">
          <div className="brand">
            <div className="logo" />
            <span>AgentExplorer</span>
          </div>
          <div className="nav-links">
            <a href="#features">Features</a>
            <a href="#demo">Demo</a>
            <a href="#contact">Contact</a>
          </div>
          <div style={{display:'flex', gap:10}}>
            <button className="cta-outline" onClick={()=>setShowDemo(true)}>Try the demo</button>
            <a className="cta-btn" href="#contact">Get started</a>
          </div>
        </div>
      </nav>

      <header className="hero">
        <div className="inner">
          <div>
            <h1>A modern workspace for AI training and retrieval</h1>
            <p className="sub">Upload documents, build retrieval pipelines, compare RAG vs. finetuning, and test everything in one visual place.</p>
            <div style={{display:'flex', gap:10, flexWrap:'wrap'}}>
              <button className="cta-btn" onClick={()=>setShowDemo(true)}>Launch interactive demo</button>
              <a className="cta-outline" href="#features">Explore features</a>
            </div>
            <div className="pills">
              <span className="pill">RAG playground</span>
              <span className="pill">Finetuning sandbox</span>
              <span className="pill">Scenario analysis</span>
              <span className="pill">Source traceability</span>
            </div>
          </div>
          <div className="video">
            <span style={{opacity:.8}}>Replace with product video / screenshot</span>
          </div>
        </div>
      </header>

      <section className="marquee">
        <div className="inner">
          <div className="scroller">
            <img src="https://dummyimage.com/120x24/ffffff/000.png&text=NASA" />
            <img src="https://dummyimage.com/140x24/ffffff/000.png&text=ESA" />
            <img src="https://dummyimage.com/180x24/ffffff/000.png&text=OpenCV" />
            <img src="https://dummyimage.com/160x24/ffffff/000.png&text=3D+Slicer" />
            <img src="https://dummyimage.com/140x24/ffffff/000.png&text=ISU" />
            <img src="https://dummyimage.com/120x24/ffffff/000.png&text=DLR" />
            <img src="https://dummyimage.com/160x24/ffffff/000.png&text=Springer" />
            <img src="https://dummyimage.com/120x24/ffffff/000.png&text=CNES" />
          </div>
        </div>
      </section>

      <section id="features" className="features">
        <div className="inner">
          <div className="grid">
            <article className="card">
              <div className="icon" />
              <h3>Upload & Index</h3>
              <p>Chunk, index, and version your lecture notes or PDFs. Full source traceability for each answer.</p>
            </article>
            <article className="card">
              <div className="icon" />
              <h3>RAG Playground</h3>
              <p>Test prompts and retrieval settings, compare top-k, filters, and see the exact chunks used.</p>
            </article>
            <article className="card">
              <div className="icon" />
              <h3>Finetuning Sandbox</h3>
              <p>Contrast RAG vs finetuning with a clear side-by-side to pick the lowest-cost, highest-accuracy path.</p>
            </article>
            <article className="card" style={{gridColumn:'span 6'}}>
              <div className="icon" />
              <h3>Scenario Simulator</h3>
              <p>Analyze human-in-the-loop, assisted, and autonomous decisions for high-stakes contexts like spaceflight or life sciences.</p>
            </article>
            <article className="card" style={{gridColumn:'span 6'}}>
              <div className="icon" />
              <h3>API-first</h3>
              <p>Clean endpoints for upload, query, and index management so your experiments remain portable.</p>
            </article>
          </div>
        </div>
      </section>

      <section id="demo" className="demo">
        <div className="inner">
          <div className="panel">
            {showDemo ? <Dashboard /> : (
              <div style={{textAlign:'center', padding:'40px 16px'}}>
                <h2>Interactive demo</h2>
                <p style={{color:'#a7b0d6'}}>Run the full experience inside this page.</p>
                <button className="cta-btn" onClick={()=>setShowDemo(true)}>Start demo</button>
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="cta" id="contact">
        <div className="box">
          <h3 style={{margin:0}}>Ready to build your AI workspace?</h3>
          <div style={{display:'flex', gap:10, flexWrap:'wrap'}}>
            <a className="cta-btn" href="#demo" onClick={(e)=>{e.preventDefault(); setShowDemo(true);}}>Open demo</a>
            <a className="cta-outline" href="mailto:hello@example.com">Contact us</a>
          </div>
        </div>
      </section>

      <footer className="footer">
        <div className="inner">
          <span>© {new Date().getFullYear()} AgentExplorer</span>
          <span>Made with ♥ for research teams</span>
        </div>
      </footer>
    </div>
  )
}
