import { useState } from 'react'
import './App.css'
import { AITraining } from './AITraining'

interface Scenario {
  id: string;
  domain: 'life-sciences' | 'spaceflight';
  title: string;
  situation: string;
  aiAssisted: string;
  aiAutonomous: string;
  humanDecision: string;
}

const scenarios: Scenario[] = [
  {
    id: 'ls1',
    domain: 'life-sciences',
    title: 'Cancer Treatment Selection',
    situation: 'Patient with stage 2 breast cancer, multiple treatment options available',
    aiAssisted: 'AI analyzes genetic markers, similar cases, and treatment outcomes. Presents top 3 options with success rates and side effects. Doctor reviews data, discusses with patient, and makes final decision.',
    aiAutonomous: 'AI automatically selects treatment based on algorithm. No human oversight. Risk: Missing patient preferences, psychological factors, or unique circumstances.',
    humanDecision: 'Doctor makes final treatment decision after reviewing AI analysis and consulting with patient'
  },
  {
    id: 'ls2',
    domain: 'life-sciences',
    title: 'Drug Interaction Alert',
    situation: 'Patient prescribed new medication, potential interaction with existing drugs',
    aiAssisted: 'AI flags potential interaction, severity level, and suggests alternatives. Pharmacist reviews alert, checks patient history, and confirms or adjusts prescription.',
    aiAutonomous: 'AI blocks prescription automatically. Risk: Could prevent legitimate treatment or miss context-specific exceptions.',
    humanDecision: 'Pharmacist decides whether to approve, modify, or reject prescription'
  },
  {
    id: 'sf1',
    domain: 'spaceflight',
    title: 'Emergency Life Support Failure',
    situation: 'CO2 scrubber malfunction on Mars mission, oxygen levels dropping',
    aiAssisted: 'AI rapidly analyzes all available resources, calculates survival scenarios, and presents 5 repair options ranked by success probability. Crew reviews options and selects best approach given their skills and tools.',
    aiAutonomous: 'AI takes control and executes repair procedure. Risk: May not account for crew physical condition, available tools, or improvisation opportunities.',
    humanDecision: 'Crew commander makes final decision on which repair strategy to attempt'
  },
  {
    id: 'sf2',
    domain: 'spaceflight',
    title: 'Orbital Debris Collision Risk',
    situation: 'Space station detects debris on collision course, 15 minutes to impact',
    aiAssisted: 'AI calculates collision probability, fuel costs for evasive maneuvers, and impact on mission timeline. Presents 3 options: immediate burn, delayed burn, or accept low-risk collision. Mission control reviews and decides.',
    aiAutonomous: 'AI executes maneuver automatically. Risk: Could waste fuel on false positive or create new collision risks.',
    humanDecision: 'Mission control decides whether to maneuver based on AI analysis and mission priorities'
  },
  {
    id: 'ls3',
    domain: 'life-sciences',
    title: 'Epidemic Outbreak Response',
    situation: 'Novel virus detected, spreading rapidly in urban area',
    aiAssisted: 'AI models transmission patterns, predicts hotspots, and simulates intervention strategies (lockdowns, vaccines, contact tracing). Public health officials use data to design response while considering social, economic, and ethical factors.',
    aiAutonomous: 'AI implements containment measures automatically. Risk: Could ignore human rights, economic hardship, or public trust issues.',
    humanDecision: 'Public health authorities decide on containment measures balancing AI predictions with societal impact'
  },
  {
    id: 'sf3',
    domain: 'spaceflight',
    title: 'Long-Duration Mission Psychology',
    situation: 'Crew member showing signs of depression on 2-year Mars mission',
    aiAssisted: 'AI monitors biometrics, voice patterns, and behavioral changes. Alerts medical officer with assessment and suggests interventions (therapy protocols, workload adjustment, communication with family). Medical officer evaluates and decides treatment.',
    aiAutonomous: 'AI adjusts crew member\'s duties and medication automatically. Risk: Lacks empathy, may miss subtle cues, could violate privacy or autonomy.',
    humanDecision: 'Medical officer decides intervention after consulting AI data and speaking with crew member'
  }
];

function Dashboard() {
  const [selectedScenario, setSelectedScenario] = useState<Scenario | null>(null);
  const [activeMode, setActiveMode] = useState<'assisted' | 'autonomous' | null>(null);
  const [selectedDomain, setSelectedDomain] = useState<'all' | 'life-sciences' | 'spaceflight'>('all');

  const filteredScenarios = scenarios.filter(s => 
    selectedDomain === 'all' || s.domain === selectedDomain
  );

  return (
    <div className="app">
      <header className="header">
        <h1>AI-Human Symbiosis Dashboard</h1>
        <p className="subtitle">Exploring Collaborative Intelligence in Life Sciences & Human Spaceflight</p>
      </header>

      <div className="philosophy-banner">
        <h2>Vivre Ensemble: Living Together</h2>
        <p>
          AI as a collaborative tool, not an autonomous decision-maker. 
          In critical domains like medicine and spaceflight, humans must retain final authority 
          while AI provides analysis, insights, and options.
        </p>
      </div>

      <div className="domain-filter">
        <button 
          className={selectedDomain === 'all' ? 'active' : ''} 
          onClick={() => setSelectedDomain('all')}
        >
          All Domains
        </button>
        <button 
          className={selectedDomain === 'life-sciences' ? 'active' : ''} 
          onClick={() => setSelectedDomain('life-sciences')}
        >
          Life Sciences
        </button>
        <button 
          className={selectedDomain === 'spaceflight' ? 'active' : ''} 
          onClick={() => setSelectedDomain('spaceflight')}
        >
          Human Spaceflight
        </button>
      </div>

      <div className="main-content">
        <div className="scenarios-panel">
          <h2>Critical Scenarios</h2>
          <p className="panel-description">
            Select a scenario to explore AI-assisted vs AI-autonomous decision-making
          </p>
          {filteredScenarios.map(scenario => (
            <div 
              key={scenario.id} 
              className={`scenario-card ${selectedScenario?.id === scenario.id ? 'selected' : ''}`}
              onClick={() => {
                setSelectedScenario(scenario);
                setActiveMode(null);
              }}
            >
              <span className={`domain-badge ${scenario.domain}`}>
                {scenario.domain === 'life-sciences' ? 'Life Sciences' : 'Human Spaceflight'}
              </span>
              <h3>{scenario.title}</h3>
              <p>{scenario.situation}</p>
            </div>
          ))}
        </div>

        <div className="analysis-panel">
          {!selectedScenario ? (
            <div className="placeholder">
              <h2>Select a scenario to begin</h2>
              <p>Choose a critical decision-making scenario from the left to explore how AI-human collaboration works in practice.</p>
              
              <div className="principles">
                <h3>Core Principles</h3>
                <div className="principle">
                  <h4>🤝 Cooperation over Control</h4>
                  <p>Like the Prisoner's Dilemma: if we design AI alignment as pure control, we create adversarial relationships. Instead, design for mutual benefit.</p>
                </div>
                <div className="principle">
                  <h4>🛡️ No Harm Foundation</h4>
                  <p>AI systems must understand context, culture, and long-term consequences. "Do no harm" includes understanding when inaction itself causes harm.</p>
                </div>
                <div className="principle">
                  <h4>⚖️ Human Authority in Critical Domains</h4>
                  <p>In life-or-death decisions (medicine, spaceflight), humans must make final calls. AI provides data, not dictates.</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="scenario-analysis">
              <h2>{selectedScenario.title}</h2>
              <div className="situation-box">
                <h3>Situation</h3>
                <p>{selectedScenario.situation}</p>
              </div>

              <div className="comparison">
                <div 
                  className={`approach-card assisted ${activeMode === 'assisted' ? 'active' : ''}`}
                  onClick={() => setActiveMode('assisted')}
                >
                  <h3>🤝 AI-Assisted (Recommended)</h3>
                  <p className="approach-label">Symbiotic Collaboration</p>
                  <p>{selectedScenario.aiAssisted}</p>
                  <div className="decision-authority">
                    <strong>Final Decision:</strong> {selectedScenario.humanDecision}
                  </div>
                </div>

                <div 
                  className={`approach-card autonomous ${activeMode === 'autonomous' ? 'active' : ''}`}
                  onClick={() => setActiveMode('autonomous')}
                >
                  <h3>🤖 AI-Autonomous (Risky)</h3>
                  <p className="approach-label">Full Automation</p>
                  <p>{selectedScenario.aiAutonomous}</p>
                  <div className="warning">
                    ⚠️ Warning: Removes human judgment and context from critical decisions
                  </div>
                </div>
              </div>

              {activeMode && (
                <div className="insight-box">
                  {activeMode === 'assisted' ? (
                    <>
                      <h3>Why This Works</h3>
                      <ul>
                        <li><strong>AI strengths:</strong> Rapid data analysis, pattern recognition, scenario simulation</li>
                        <li><strong>Human strengths:</strong> Contextual judgment, ethical reasoning, empathy, accountability</li>
                        <li><strong>Together:</strong> Faster, more informed decisions that respect human values and complexity</li>
                      </ul>
                    </>
                  ) : (
                    <>
                      <h3>Why This Is Problematic</h3>
                      <ul>
                        <li><strong>Context blindness:</strong> AI may miss unique circumstances or human factors</li>
                        <li><strong>Accountability gap:</strong> Who is responsible when AI makes a wrong decision?</li>
                        <li><strong>Loss of autonomy:</strong> Reduces human agency in decisions that affect their lives</li>
                        <li><strong>Trust erosion:</strong> People distrust systems that make unilateral decisions</li>
                      </ul>
                    </>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <AITraining />

      <footer className="footer">
        <p>
          <strong>Mission:</strong> Demonstrate that the future of AI is not about replacement, 
          but about symbiosis - humans and AI working together, each contributing their unique strengths.
        </p>
      </footer>
    </div>
  )
}

export default Dashboard
