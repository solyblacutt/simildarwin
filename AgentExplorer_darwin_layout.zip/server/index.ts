import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { LocalIndex } from 'vectra';
import OpenAI from 'openai';
import path from 'path';
import fs from 'fs';
import { PDFParse } from 'pdf-parse';

const app = express();
const PORT = 3000;

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(cors());
app.use(express.json());

// Setup file upload
const upload = multer({
  dest: 'uploads/',
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Initialize Vectra index
const indexPath = path.join(process.cwd(), 'vector-index');
let vectorIndex: LocalIndex;

async function initializeIndex() {
  try {
    vectorIndex = new LocalIndex(indexPath);
    if (!await vectorIndex.isIndexCreated()) {
      await vectorIndex.createIndex();
      console.log('Vector index created successfully');
    } else {
      console.log('Using existing vector index');
    }
  } catch (error) {
    console.error('Error initializing index:', error);
  }
}

// Initialize on startup
initializeIndex();

// Helper function to chunk text into smaller pieces
function chunkText(text: string, chunkSize: number = 800, overlap: number = 100): string[] {
  const chunks: string[] = [];
  let start = 0;
  
  while (start < text.length) {
    const end = Math.min(start + chunkSize, text.length);
    chunks.push(text.slice(start, end));
    start += chunkSize - overlap;
  }
  
  return chunks;
}

// Helper function to get embeddings from OpenAI
async function getEmbedding(text: string): Promise<number[]> {
  const response = await openai.embeddings.create({
    model: 'text-embedding-3-small',
    input: text,
  });
  return response.data[0].embedding;
}

// Extract text from PDF
async function extractTextFromPDF(filePath: string): Promise<string> {
  try {
    const dataBuffer = fs.readFileSync(filePath);
    const parser = new PDFParse({ data: dataBuffer });
    const result = await parser.getText();
    await parser.destroy();
    return result.text;
  } catch (error: any) {
    console.error('PDF parsing error:', error);
    throw new Error(`Failed to parse PDF: ${error.message}`);
  }
}

// Upload and process lecture notes
app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const { originalname, path: filePath } = req.file;
    let text = '';

    // Extract text based on file type
    if (originalname.endsWith('.pdf')) {
      text = await extractTextFromPDF(filePath);
    } else if (originalname.endsWith('.txt')) {
      text = fs.readFileSync(filePath, 'utf-8');
    } else {
      fs.unlinkSync(filePath);
      return res.status(400).json({ error: 'Unsupported file type. Please upload PDF or TXT files.' });
    }

    // Chunk the text
    const chunks = chunkText(text);
    console.log(`Processing ${chunks.length} chunks from ${originalname}`);

    // Process each chunk and store in vector database
    let processedChunks = 0;
    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      const embedding = await getEmbedding(chunk);
      
      await vectorIndex.upsertItem({
        id: `${originalname}-chunk-${i}`,
        vector: embedding,
        metadata: {
          filename: originalname,
          chunkIndex: i,
          totalChunks: chunks.length,
          text: chunk
        }
      });
      
      processedChunks++;
    }

    // Clean up uploaded file
    fs.unlinkSync(filePath);

    res.json({
      success: true,
      message: `Successfully processed ${processedChunks} chunks from ${originalname}`,
      chunks: processedChunks
    });

  } catch (error: any) {
    console.error('Upload error:', error);
    res.status(500).json({ error: error.message || 'Failed to process file' });
  }
});

// Query the knowledge base
app.post('/api/query', async (req, res) => {
  try {
    const { question } = req.body;

    if (!question) {
      return res.status(400).json({ error: 'Question is required' });
    }

    // Get embedding for the question
    const questionEmbedding = await getEmbedding(question);

    // Search for similar chunks in the vector database
    const results = await vectorIndex.queryItems(questionEmbedding, 3);

    if (results.length === 0) {
      return res.json({
        answer: 'No relevant information found in the uploaded lecture notes. Please upload some lecture materials first.',
        sources: []
      });
    }

    // Prepare context from retrieved chunks
    const context = results.map((result, index) => {
      const metadata = result.item.metadata as any;
      return `[Source ${index + 1}: ${metadata.filename}, chunk ${metadata.chunkIndex + 1}/${metadata.totalChunks}]\n${metadata.text}`;
    }).join('\n\n');

    // Generate answer using GPT with RAG context
    const completion = await openai.chat.completions.create({
      model: 'gpt-5', // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages: [
        {
          role: 'system',
          content: 'You are a helpful educational AI assistant. Use the provided lecture note excerpts to answer questions. If the information is not in the context, say so. Always cite which source you used.'
        },
        {
          role: 'user',
          content: `Context from lecture notes:\n\n${context}\n\nQuestion: ${question}\n\nPlease answer the question based on the lecture notes above. Cite which sources you used.`
        }
      ],
      max_completion_tokens: 1000
    });

    const answer = completion.choices[0].message.content;

    // Format sources
    const sources = results.map(result => {
      const metadata = result.item.metadata as any;
      return {
        filename: metadata.filename,
        chunkIndex: metadata.chunkIndex,
        totalChunks: metadata.totalChunks,
        text: metadata.text.substring(0, 200) + '...',
        score: result.score
      };
    });

    res.json({
      answer,
      sources
    });

  } catch (error: any) {
    console.error('Query error:', error);
    res.status(500).json({ error: error.message || 'Failed to process query' });
  }
});

// Get index statistics
app.get('/api/stats', async (req, res) => {
  try {
    const items = await vectorIndex.listItems();
    const uniqueFiles = new Set(items.map(item => (item.metadata as any)?.filename));
    
    res.json({
      totalChunks: items.length,
      totalFiles: uniqueFiles.size,
      files: Array.from(uniqueFiles)
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to get stats' });
  }
});

// Clear the index
app.delete('/api/clear', async (req, res) => {
  try {
    await vectorIndex.deleteIndex();
    await vectorIndex.createIndex();
    res.json({ success: true, message: 'Knowledge base cleared' });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to clear index' });
  }
});

app.listen(PORT, () => {
  console.log(`RAG API server running on port ${PORT}`);
});
